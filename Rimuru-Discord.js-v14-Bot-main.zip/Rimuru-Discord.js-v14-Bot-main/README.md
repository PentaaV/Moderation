

<h1>Rimuru Discord Botu v14 </h1>
<p>.gg/mondstadt</p>

##  Proje Hakkında

Aldığınız hataları bana discord hesabımdan iletebilirsiniz. 
Discord id: oktayyavuzjp
